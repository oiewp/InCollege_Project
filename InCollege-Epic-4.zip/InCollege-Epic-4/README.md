# READ ME

## Setting Up Dependencies
Run the following commands:
1. pip install flask
2. pip install flask-login
3. pip install flask-sqlalchemy

## Running the application
For Windows:
  Run the command: "python main.py"

For Mac:
  Run the command "python3 main.py"

Copy the host name ending with 8080 and paste into a browser's address bar