from flask import Blueprint, flash, render_template, request
from flask_login import login_required, current_user
from . import db
from flask import redirect, url_for 
from .models import User
from sqlalchemy import and_, func

views = Blueprint('views', __name__)

@views.route('/', methods=['GET', 'POST'])
def front_page():
  return render_template("front_page.html", user=current_user)

@views.route('/incollege-video', methods=['GET', 'POST'])
def incollege_video():
  flash('Video is playing.', category='success')
  return render_template("incollege_video.html", user=current_user)

# help-center route
@views.route('/help-center', methods=['GET', 'POST'])
def help_center():
  return render_template("help_center.html", user=current_user)

# about route
@views.route('/about', methods=['GET', 'POST'])
def about():
  return render_template("about.html", user=current_user)


# Links below will require the user to be logged in to access them
@views.route('/home', methods=['GET', 'POST'])
@login_required
def home():
  return render_template("home.html", user=current_user)

@views.route('/job-search', methods=['GET', 'POST'])
@login_required
def job_search():
  return render_template("job_search.html", user=current_user)

# Accessibility route
@views.route('/accessibility', methods=['GET', 'POST'])
def accessibility():
    return render_template("accessibility.html", user=current_user)

@views.route('/finder', methods=['GET', 'POST'])
@login_required
def finder():
  #initialize variables outside of if statement so that finder.html does not encounter an error for undefined variables
  match_found = False
  matching_users = []

  if (request.method == 'POST'):
    lname = request.form.get('lname')

    matching_users = User.query.filter(func.lower(User.lname)==func.lower(lname)).all()
    if not matching_users:
      flash('No users with a matching last name were found.', category='error')
    else:
      flash(f'Users with the last name {lname} found!', category='success')
      match_found = True

  return render_template("finder.html", matching_users=matching_users, user=current_user, match_found=match_found)


@views.route('/skills', methods=['GET', 'POST'])
@login_required
def skills():
  return render_template("skill.html", user=current_user)

@views.route('/skills/<int:skill_id>', methods=['GET'])
@login_required
def learn_skill(skill_id):
    skills = {
      1: {'name': 'Programming Languages'},
      2: {'name': 'Graphic Design'},
      3: {'name': 'Digital Marketing'},
      4: {'name': 'Data Analysis and Visualization'},
      5: {'name': 'Public Speaking and Presentation'}
    }

    skill = skills.get(skill_id)
    if skill:
        return render_template("skill_details.html", user=current_user, skill=skill)
    else:
        return redirect(url_for('views.home'))

# privacy-policy route

@views.route('/privacy-policy', methods=['GET', 'POST'])
@login_required
def privacy_policy():
    if request.method == 'POST':
        # Extract form data and update current_user's settings
        current_user.email_option = 'emailOption' in request.form
        current_user.sms_option = 'smsOption' in request.form
        current_user.advertising_option = 'advertisingOption' in request.form

        try:
            db.session.commit()
            flash('Your settings have been updated.', 'success')
        except:
            db.session.rollback()
            flash('An error occurred. Please try again.', 'error')
        return redirect(url_for('views.privacy_policy'))

    return render_template("privacy_policy.html", user=current_user)

# Copyright Policy route
@views.route('/copyright-policy', methods=['GET', 'POST'])
def copyright_policy():
    return render_template("copyright_policy.html", user=current_user)

# User Agreement route
@views.route('/user-agreement', methods=['GET', 'POST'])
def user_agreement():
    return render_template("user_agreement.html", user=current_user)

# copyright notice route
@views.route('/copyright-notice', methods=['GET', 'POST'])
def copyright():
  return render_template("notice.html", user=current_user)

# Cookie Policy and Settings route
@views.route('/cookie-policy', methods=['GET', 'POST'])
def cookie_policy():
    return render_template("cookie_policy.html", user=current_user)

# Brand Policy route
@views.route('/brand-policy', methods=['GET', 'POST'])
def brand_policy():
    return render_template("brand_policy.html", user=current_user)

# language route
@views.route('/languages', methods=['GET', 'POST'])
@login_required
def language():
    if request.method == 'POST':
        # Extract form data
        selected_language = request.form.get('language')

        # Update current_user's settings
        current_user.language = selected_language

        try:
            # Save to database
            db.session.commit()
            flash('Your language settings have been updated.', 'success')
        except Exception as e:
            db.session.rollback()
            flash('An error occurred. Please try again.', 'error')
        return redirect(url_for('views.language'))

    # No need to modify anything here for GET request handling
    # Just ensure the current language is passed to the template
    return render_template("language.html", user=current_user)


#################################################################
#                       UNDER CONSTRUCTION                      #
#################################################################


# press route
@views.route('/press', methods=['GET', 'POST'])
def press():
  return render_template("press.html", user=current_user)

# blog route
@views.route('/blog', methods=['GET', 'POST'])
def blog():
  return render_template("under_construction.html", user=current_user)

# careers
@views.route('/careers', methods=['GET', 'POST'])
def careers():
  return render_template("under_construction.html", user=current_user)

# developers route
@views.route('/developers', methods=['GET', 'POST'])
def developers():
  return render_template("under_construction.html", user=current_user)

# browse incollege route
@views.route('/browse-incollege', methods=['GET', 'POST'])
def browse():
  return render_template("under_construction.html", user=current_user)

# business solution route
@views.route('/business-solutions', methods=['GET', 'POST'])
def business():
  return render_template("under_construction.html", user=current_user)

# directories route
@views.route('/directories', methods=['GET', 'POST'])
def directories():
  return render_template("under_construction.html", user=current_user)

# search by university route
@views.route('/search-by-uni', methods=['GET', 'POST'])
def search_uni():
   return render_template("under_construction.html", user=current_user)

# search by major route
@views.route('/search-by-major', methods=['GET', 'POST'])
def search_major():
   return render_template("under_construction.html", user=current_user)

# add friend route
@views.route('/add-friend', methods=['GET', 'POST'])
def add_friend():
   return render_template("under_construction.html", user=current_user)